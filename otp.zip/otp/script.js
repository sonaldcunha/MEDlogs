let counter = document.querySelector('h1');
let count = 1;

setInterval(()=>{

    counter.innerText = count;
    count++
    
    if(count > 30) location.replace('http://127.0.0.1:5500/failed.html')
    
},1000)