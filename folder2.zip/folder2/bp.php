<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>BLOOD PRESSURE</title>
  <style>
    input[type=text], select, textarea{
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  resize: vertical;
}

/* Style the label to display next to the inputs */
label {
  padding: 12px 12px 12px 0;
  display: inline-block;
}

/* Style the submit button */
input[type=submit] {
  background-color: #04AA6D;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  float: right;
}

/* Style the container */
.container {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}

/* Floating column for labels: 25% width */
.col-25 {
  float: left;
  width: 25%;
  margin-top: 6px;
}
.update{
      background-color:rgb(166, 194, 199);
      color:rgb(2, 16, 46);
      border:0;

      outline:none;
      border-radius:5px;
      height:35px;
      width:100px;
      font-weight:bold;
      cursor:pointer;
    }

/* Floating column for inputs: 75% width */
.col-75 {
  float: left;
  width: 75%;
  margin-top: 6px;
}
/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive layout - when the screen is less than 600px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
  .col-25, .col-75, input[type=submit] {
    width: 100%;
    margin-top: 0;
  }
}

  </style>
</head>
<body>
  <h1 align="center">ADD YOUR BLOOD PRESSURE VALUES</h1>
  <div class="container">
    
    <form method="POST" action="bp.php">
      
      <div class="row">
        <div class="col-25">
          <label for="pressure">SYSTOLIC PRESSURE</label>
           <input type="float" id="pressure" name="sys_pressure"
                 min="0" max="250">
                </div>

                <div class="row">
                  <div class="col-25">
                    <label for="pressure">DIASTOLIC PRESSURE</label>
                     <input type="float" id="pressure" name="dias_pressure"
                           min="0" max="2500">
                          </div>
                          </div>

                          <div class="row">
                  <div class="col-25">
                    <label for="pressure">DATE OF RECORDING</label>
                     <input type="date" name="date">
                          </div>
                          </div>

                          <div class="row">
                            <div class="col-25">
                              <p>Are you taking any blood pressure tablets?</p>
                              <input type="radio" id="yes" name="tablets" value="yes">
                              <label for="yes">YES</label><br>
                              <input type="radio" id="no" name="tablets" value="no">
                              <label for="no">NO</label><br>
                              
                                    </div>
                                    </div>
                          
      <div class="row">
        <input type="submit" name="submit" value="Submit">
        </div>
        <div class="row"><a href="bpanalysis.php" class="update">View graph</a>
    </form>
  </div>
  <br><br><br><br><br>
  <br><br><br><br><br><br><br>
  <a href="admin-panel.php" style="color:black;">Back to MEDlogs features</a>
</body>
</html>
<?php
include 'dbconn.php';
if(isset($_POST['submit']))
{
  $sys_pressure= $_POST['sys_pressure'];
  $dias_pressure= $_POST['dias_pressure'];
  $date=$_POST['date'];
  $tablets=$_POST['tablets'];
  $insertquery= "insert into bp (sys_pressure,dias_pressure,date,tablets) VALUES('$sys_pressure','$dias_pressure','$date','$tablets')";
  if($con->query($insertquery))
     {
        ?>
        <script>
        alert("inserted successfully");
        </script>
        <?php
     }
   else
   {
    ?>
    <script>
    alert("failed to insert");
    </script>
    <?php
 }
}   
?>
