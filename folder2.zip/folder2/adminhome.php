
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin home page</title>
    <link rel="stylesheet" href="<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hospital home page</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <style>
    .update{
  float: left;
  }
 
  </style>
</head>
<style>
    .bp{
        text-align: center;
        padding-top: 100px;
        color: aliceblue;
    }
    
.colour{
    background-color: rgb(6, 7, 41);
  
};
.footcol{
    background-color: rgb(6, 7, 41);
}

.update{
      background-color:rgb(166, 194, 199);
      color:rgb(2, 16, 46);
      border:0;
      outline:none;
      border-radius:5px;
      height:50px;
      width:250px;
      font-weight:bold;
      cursor:pointer;
    }

</style>
<body style="background-image: url(https://wallpaperaccess.com/full/186075.jpg);">
  
    
  
    <div class="bp">
        <h1>Welcome to MEDlogs</h1>
        <br><br><br><br>
    </div>

    <div><a href='adminuser.php'><input type='submit' value='UPDATE USERS' class='update'></a> </div><br><br>
    <div><a href='adminhosp.php'><input type='submit' value='UPDATE HOSPITALS' class='update'></a> </div><br><br>
    <div><a href='overallreport.php'><input type='submit' value='GENERATE REPORT' class='update'></a> </div><br><br>
    <div><a href='usernotify.php'><input type='submit' value='UPDATE BLOGS' class='update'></a> </div><br><br>
    <!-- <div><a href='#'><input type='submit' value='SEND REMINDERS' class='update'></a> </div> -->
    <div ><form action="adminlogout.php" method="POST"> 
      <button class='update' type="submit" name="logout_btn" class="btn btn-primary">LOGOUT</button>
</form><div>
    


    

 
    
  <br><h1>.</h1>

   
</body>
<footer>
    <div class="footcol">
<br><br>

    </div>
</footer>
</html>


