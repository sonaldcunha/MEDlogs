<?php
include('security1.php');

if(isset($_POST['login_btn']))
{
    $username = $_POST['username']; 
    $password_login = $_POST['passwordd']; 

    $query = "SELECT * FROM adminlogin WHERE username='$username' AND password='$password_login' LIMIT 1";
    $query_run = mysqli_query($connection, $query);

   if(mysqli_fetch_array($query_run))
   {
        $_SESSION['username'] = $username;
        header('Location: adminhome.php');
   } 
   else
   {
        $_SESSION['status'] = "username / Password is Invalid";
        header('Location: login.php');
   }
    
}
?>