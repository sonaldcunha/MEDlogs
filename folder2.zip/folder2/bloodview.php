<html>

<head>
  <style>
    body {
      background: linear-gradient(135deg, lightgreen, #7e97af);
    }

    .delete,
    .update {
      background-color: blueviolet;
      color: white;
      border: 0;
      outline: none;
      border-radius: 5px;
      height: 23px;
      width: 80px;
      font-weight: bold;
      cursor: pointer;
    }

    .delete {
      background-color: lightseagreen;
    }
  </style>

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">

</head>

<body>

  <?php
  include 'dbcon.php'; ?>

  <div class="container">
    <div class="table-responsive">
      <div class="card" style="margin-top: 15vh">
        <div class="card-header">
          <a class="btn btn-warning float-right" href="blood.php">Back to blood donation page</a>

        </div>
        <div class="card-body">
          <table class="table">
            <tr>
              <th>DATE</th>
              <th>BLOODGROUP</th>
              <th>UNITS OF BLOOD</th>
              <th>CENTRE</th>
              <th>ACTIONS</th>
            </tr>

            <?php
            $query = "select * from blood";
            $data = mysqli_query($con, $query);
            $result = mysqli_num_rows($data);

            if ($result) {
              while ($row = mysqli_fetch_array($data)) {
            ?>
                <tr>
                  <td><?php echo $row['date'] ?></td>
                  <td><?php echo $row['bloodgroup'] ?></td>
                  <td><?php echo $row['units'] ?></td>
                  <td><?php echo $row['centre'] ?></td>
                  <td><a href="bloodupdate.php?blood_id=<?php echo $row['blood_id']; ?>"><input type='submit' value='UPDATE' class='update'></a>
                    <a href="blooddelete.php?blood_id=<?php echo $row['blood_id']; ?>"><input type='submit' value='DELETE' class='delete' onclick='return checkdelete()'></a>
                  </td>

                </tr>

              <?php
              }
              ?>
          </table>
        </div>
      </div>


    </div>
  </div>

  <!-- <script> -->
  <!-- alert("the data is displayed"); -->

  <!-- </script> -->

<?php

            } else {
?>
  <script>
    alert("failed to display");
  </script>
<?php
            }

?>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>

<script>
  function checkdelete() {
    return confirm('Are you sure you want to delete this record?');
  }
</script>
</body>

</html>