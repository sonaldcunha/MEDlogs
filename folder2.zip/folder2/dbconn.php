<?php
$server= "localhost";
$user= "root";
$password= "root";
$db= "chartjs";
$con = mysqli_connect($server,$user,$password,$db);

if($con){
  ?>
  
  <?php
}
else{
  ?>
  <script>
    alert("NO connection ");
  </script>
  <?php
}
?> 