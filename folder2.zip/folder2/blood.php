<?php
          session_start();
          error_reporting(0);
          if ($_SERVER['REQUEST_METHOD'] == 'GET') {
            $isLoggedin = $_SESSION['pid'];
            if (!$isLoggedin) {
              header('Location: http://medical.test/medLOGS/index.php');
            }
          }
?><!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Blood donation</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">

  <style>
      @import url("https://fonts.googleapis.com/css?family=Assistant:400,700|Playfair+Display:900");
   
   :root {
       --backgroundColor: #807878;
       --logo-color: #181818;
       --font-all: "Assistant", sans-serif;
       --icon-color: #ff1414;
       --card-back1: tomato;
       --card-font: #fff;
   }
   
   
   
   html, body {
       
       font-family: var(--font-all);
       font-size: 1.1em;
       background-image:url(https://images.freecreatives.com/wp-content/uploads/2016/02/Blue-Gradient-Background-For-Free-Download.jpg);
   }
   body{
    background: linear-gradient(135deg, lightgreen, #7e97af);
    }
   

   header, main, section{
       display: flex;
       flex-direction: column;
       align-items: center;
       align-content: center;
       align-self: center;
       text-align: center;
       margin: 0 auto;
   }
   
   header, main {
       margin-bottom: 5vh;
       width: 90%;
       max-width: 500px;
   }
   
   .form{
       padding-left: 100px;
       padding-right: 100px;
       max-width: 500px;
   }
   
   .form input{
     padding-right: 20px;
     margin-bottom: 9px;
   }
   
   
   
   
   
   
   
   .logo {
       color: var(--logo-color);
   }
   
   i.fas {
       color: var(--icon-color);
       font-size: 100px;
   }    
   
   
   
   main h2 {
       color: var(--logo-color);
       margin-bottom: 8vh;
       font-size: 3em;
   }
   
   main h2 span{
       color: var(--icon-color);
   }
   
   main h3 {
       color: var(--icon-color);
       line-height: 25px;   
   }
   
   .blood {
       display: flex;
       align-items: center;
       position: relative;
       justify-content: center;
   }
   
   .donors {
       display: grid;
       grid-template-columns:  1.5fr 1.5fr 1.5fr 1.5fr;
   }
   
   
   
   
   
   .blood::before {
       content: "";
       background: tomato;
       width: 40px;
       height: 40px;
       position: absolute;
       border-radius: 50%;
       border-top-right-radius: 0;
       transform: rotate(-45deg);
       opacity: 0.2;
       z-index: 1;
   }
   
   @media screen and (max-width: 480px) {
       section.form {
           display: flex;
           flex-direction: column;
           line-height: 5vh;
       }
       .donors {
           display: grid;
           grid-template-columns:  1fr;
           margin-bottom: 2vh;
       }
       .donors p {
            margin-bottom: 5vh;
       }
       main h2 {
           line-height: 8vh;
       }
   }
   .update{
        background-color:lightcoral;
      color:white;
      border:0;
      outline:none;
      border-radius:5px;
      height:25px;
      width:80px;
      font-weight:bold;
      cursor:pointer;
      }
   
   @media (prefers-color-scheme: dark) {
   :root {
       --backgroundColor: #000;
       --logo-color: #fff;
       --card-font: #fff;
   }
   header p {
           color: #fff;
       }
       section p {
           color: #fff;
       }
       footer {
           color: #fff
       }
    section > form button {
           color: #000;
       }
   }
   
   @-ms-viewport {
   width: device-width;
   }
      </style>
  </head>
  
  <body>
  


    <header class="text-white">

      <h3 class="mt-5" style="color:white;font-weight:bold">YOUR DONATION MATTERS </h3>
      <p>
          Three lives can be saved with one donation still
      </p>

      <p>
          More than 38k donates are necessary everyday
      </p>

      
  </header>

  <section class="form">

    

      <form method="POST" action="blood.php">

          <p>Enter date of blood donation: </p><input class="form-control" type="date" name="date" required>

          <p>Enter your blood group:</p><input type="text"  class="form-control"  name="bloodgroup"  required>

          <p>Enter the units of blood donated:</p><input type="text"  class="form-control"  name="units"  required>

          <p>Enter the blood donation centre:</p><input type="text"  class="form-control"  name="centre"  required><br>
          

          <button type="submit" name="submit" class="btn btn-primary"> Submit</button>
          
         <a class="btn btn-primary"  href="bloodview.php" >View</a>
          

         
</section>
<main>
    <div>
    <a href="admin-panel.php" style="color:#ffffff;">Back to MEDlogs features</a>
</div>

      <br>
      <h2>KEEP <span>donating!!</span></h2>
      <section class="donors">
      <div class="donor">
        <h3 class="blood"><strong>A+</strong></h3>
      </div>
      <div class="donor">
        <h3 class="blood"><strong>B+</strong></h3>
      </div>
      <div class="donor">
        <h3 class="blood"><strong>AB+</strong></h3>
      </div>
      <div class="donor">
        <h3 class="blood"><strong> O+ </strong></h3>
      </div>
      <br><br>
</section>    
</main>
</form>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js" integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V" crossorigin="anonymous"></script>



  </body>
</html>

<?php
include 'dbcon.php';
if(isset($_POST['submit']))
{
  $date= $_POST['date'];
  $bloodgroup= $_POST['bloodgroup'];
  $units=$_POST['units'];
  $centre=$_POST['centre'];
  $insertquery= "insert into blood (date,bloodgroup,units,centre) VALUES('$date','$bloodgroup','$units','$centre')";
  if($con->query($insertquery))
     {
        ?>
        <script>
        alert("inserted successfully");
        </script>
        <?php
     }
   else
   {
    ?>
    <script>
    alert("failed to insert");
    </script>
    <?php
 }
}   
?>
