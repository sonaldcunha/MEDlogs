<?php

include 'func1.php';

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search doctors</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <style>
    .search{
      height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 10px;
  background: linear-gradient(135deg, lightgreen, #7e97af);
    }
    </style>
    <body>
      
    <form method="POST">
      <div class=search>
           <div align="center" class="search-bar" style="margin: left 3em;"><br><br>
           <input type="text" type="search" name="search" placeholder="Find Doctors...">
    <button class="btn btn-dark btn-sm"  name="submit">SEARCH</button></form>
      <div class="container my-5">
        <table class="table">
</div>


</body>
<footer>
<a href="admin-panel.php" style="color:white;">Back to MEDlogs features</a>
  </footer>


</html>
<?php

if(isset($_POST['submit']))
{
  
  $search= $_POST['search'];
  
  
  
  $sql="select * from doctb where username like '%$search%' or  spec like '%$search%'  ";
  $result= mysqli_query($con, $sql);
  if($result){
    if(mysqli_num_rows($result)>0){
      echo'<thead><tr>
      <th>DOCTOR NAME</th>
      
      <th>DOCTOR EMAIL</th>
      <th>DOCTOR SPECIALIZATION</th>
      
      </tr></thead>';
      while($row=mysqli_fetch_assoc($result)){
      echo '<tbody>
      <tr>
      
      <td>'.$row['username'].'</td>
      <td>'.$row['email'].'</td>
      <td>'.$row['spec'].'</td>
      
      </tr></tbody>';
    }
  }
    else
    {
      ?>
      <script>
      alert("Data not found ");
      
      </script>
      <?php
    }
    
  }
}
?>