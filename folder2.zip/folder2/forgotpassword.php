<!DOCTYPE html>
<html>
<head>
	<title>Forgot Password</title>
</head>
<body>
	<h2>Forgot Password</h2>
	<form action="forgotpassword.php" method="POST">
		<label>Email:</label>
		<input type="email" name="email" required><br><br>
		<input type="submit" name="submit" value="Reset Password">
	</form>
</body>
</html>
<?php
// check if form is submitted
if(isset($_POST['submit'])){
    // get input email
    $email = $_POST['email'];
    
    // validate email
    if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
        echo "Invalid email format";
    }else{
        // check if email exists in database
        // replace with your database credentials and query
        $db_host = "localhost";
        $db_user = "root";
        $db_pass = "";
        $db_name = "myhmsdb";
        $conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
        $sql = "SELECT * FROM patreg WHERE email='$email'";
        $result = mysqli_query($conn, $sql);
        if(mysqli_num_rows($result) == 0){
            echo "Email not found";
        }else{
            // generate random token
            $token = bin2hex(random_bytes(50));
            
            // save token to database
            // replace with your database credentials and query
            $sql = "UPDATE patreg SET token='$token' WHERE email='$email'";
            mysqli_query($conn, $sql);
            
            // send email with reset password link
            $to = $email;
            $subject = "Reset Password";
            $message = "Please click on this link to reset your password:\n\n";
            $message .= "http://example.com/reset_password.php?email=".$email."&token=".$token;
            $headers = "From: webmaster@example.com\r\n";
            mail($to, $subject, $message, $headers);
            
            echo "Password reset link has been sent to your email";
        }
        mysqli_close($conn);
    }
}
?>