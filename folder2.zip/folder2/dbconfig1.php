<?php

$server_name = "localhost";
$db_username = "root";
$db_password = "root";
$db_name = "admin";

$connection = mysqli_connect($server_name,$db_username,$db_password,$db_name);


?>
