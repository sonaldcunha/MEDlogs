<?php 
	session_start();
	require("config1.php");
	
	if(!isset($_SESSION["pid"])){
		header("location:index.php");
	}
	$sql="delete from users where ID='{$_GET["id"]}'";
	if($con->query($sql)){
		header("location:add_reminder.php");
	}
?>