<?php
$host="localhost";
$user="root";
$pass="root";
$db="pdf";

$conn=mysqli_connect($host,$user,$pass,$db);

 ?>