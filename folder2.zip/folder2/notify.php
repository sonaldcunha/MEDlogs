<!DOCTYPE html>
<html>
 <head>
  <title>Notification </title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 </head>
 <body>
  <br /><br />
  <div id="topbar" class="d-flex align-items-center fixed-top">
    <div class="container d-flex justify-content-between">
      <div class="contact-info d-flex align-items-center">
        <i class="bi bi-envelope"></i> <a href="mailto:MEDlogs11@gmail.com">contact: MEDlogs11@gmail.com</a>
        <i class="bi bi-phone"></i> +91 9912345678
      </div>
      <div class="d-none d-lg-flex social-links align-items-center">
        <a href="#" class="twitter"><i class="bi bi-twitter"></i></a>
        <a href="#" class="facebook"><i class="bi bi-facebook"></i></a>
        <a href="#" class="instagram"><i class="bi bi-instagram"></i></a>
        <a href="#" class="linkedin"><i class="bi bi-linkedin"></i></i></a>
      </div>
    </div>
  </div>
  <div class="container">
   <nav class="navbar navbar-inverse">
    <div class="container-fluid">
     <div class="navbar-header">
      <a class="navbar-brand" href="#"></a>
     </div>
     <ul class="nav navbar-nav navbar-right">
      <li class="dropdown">
       <a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="label label-pill label-danger count" style="border-radius:10px;"></span> <span class="glyphicon glyphicon-bell" style="font-size:18px;"></span></a>
       <ul class="dropdown-menu"></ul>
      </li>
     </ul>
    </div>
   </nav>
   <br />
   
   
  </div>
  <link href="https://fonts.googleapis.com/css?family=Raleway:100,200,300,400,500,600,700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/fontawesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="../Css/bootstrap/bootstrap.css">
    <style>
        *{
  padding: 0;
  margin: 0;
  
}
body{
  background-color: lightblue;
}

.about-1{
  margin: 30px;
  padding: 5px;
  font-size: 20px;
}
.about-1 h1{
  text-align: center;
  color: rgb(236, 241, 243);
  font-weight: bold;
}
.about-1 p{
  text-align: center;
  padding: 3px;
  color: #b8b2b2;
}

.about-item{
  margin-bottom: 20px;
  margin-top: 20px;
  background-color: white;
  padding: 80px 30px;
  box-shadow: 0 0 9px rgba(0,0,0.6);
}

/*======================================
adding style to the icons(book,globe,pencil)
=========================================*/
.about-item i{
  font-size: 43px;
  margin: 0;
}

/*======================================
adding style to h3(heading 3) of each item 
=========================================*/
.about-item h3{
  font-size: 25px;
  margin-bottom: 10px;
}

/*======================================
styling the hr (the blue line in between)
=========================================*/
.about-item hr{
  width: 46px;
  height: 3px;
  background-color: #5fbff9;
  margin: 0 auto;
  border: none;
  text-align: center;
}

.about-item:hover{
  background-color: lightgreen;
}
.about-item:hover i,
.about-item:hover h3,
.about-item:hover p{
  color: #fff;
}
.about-item:hover hr{
  background-color: #fff;
}
.about-item:hover i{
  transform: translateY(-20px);
}
.about-item:hover i,
.about-item:hover h3,
.about-item:hover hr{
  transition: all 400ms ease-in-out;
}

footer{
  background: #212226;
  padding: 20px;
}
footer p{
  color: #fff;
}

@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');
body{
	line-height: 1.5;
	font-family: 'Poppins', sans-serif;
  
    background: linear-gradient(135deg, lightgreen, #7e97af);
    
}
*{
	margin:0;
	padding:0;
	box-sizing: border-box;
}
.container{
	max-width: 1170px;
	margin:auto;
}
.row{
	display: flex;
	flex-wrap: wrap;
}
ul{
	list-style: none;
}
.footer{
	background: linear-gradient(135deg, lightgreen, #7e97af);
    padding: 70px 0;
}
.footer-col{
   width: 25%;
   padding: 0 15px;
   float: left;
}
.footer-col h3{
	font-size: 18px;
	color: #ffffff;
	text-transform: capitalize;
	margin-bottom: 35px;
	font-weight: 500;
	position: relative;
  
}

.footer-col h6{
	font-size: 18px;
	color: #ffffff;
  white-space: nowrap;
  display: inline-block;
	
}
.footer-col h3::before{
	content: '';
	position: absolute;
	left:0;
	bottom: -10px;
	background-color: #e91e63;
	height: 2px;
	box-sizing: border-box;
	width: 50px;
}

.animate{
  padding-top: 1px;
  padding-left: 780px;
  
}

@media(max-width: 767px){
  .footer-col{
    width: 50%;
    margin-bottom: 30px;
}
}
@media(max-width: 574px){
  .footer-col{
    width: 100%;
}
}
</style>

</head>
<body>

 <section id="ABOUT">
     
     <div id="about-2">
     <div class="content-box-lg">
         <div class="container">
             <div class="row">
                 <div class="col-md-4">
                    <div class="about-item text-center">
                     <i class="fa fa-book"></i>
                     <h3>BLOGS</h3><br>
                     <img src="https://www.pilawyers.com/assets/pfeifermorganstesiak/media/images/blog/medical-files-with-stethoscope-social.jpg" width="65%">
                     <p><br><br>
                     Our blogs are designed to be informative, entertaining, and thought-provoking, providing you with the latest trends, news, and opinions on the topics you care about. With our user-friendly interface, it's easy to browse and discover new blogs that interest you, and our commenting system makes it easy to engage with other readers and share   thoughts and opinions. 
                      </p>
                     </div>
                 </div>
                 <div class="col-md-4">
                    <div class="about-item text-center">
                     <i class="fa fa-globe"></i>
                     <h3>PREGNANCY DRIVES</h3><br>
                     <img src="https://th.bing.com/th/id/OIP.BjuwE-p2Edp2I4KdKmgAgwHaE8?pid=ImgDet&rs=1" width="65%">
                     <br><br><br>
                     <p> With this campaign, we aim to raise awareness about the importance of proper nutrition,and prenatal care during pregnancy. Our team of experienced healthcare professionals will be on hand to provide guidance, and resources to help ensure a healthy pregnancy and delivery. We understand that pregnancy can be an exciting yet overwhelming time.  </p>
                     </div>
                 </div>
                 <div class="col-md-4">
                    <div class="about-item text-center">
                     <i class="fa fa-pencil"></i>
                     <h3>VACCINATION</h3><br>
                     <img src="https://img.freepik.com/free-vector/vaccination-campaign_22588-19.jpg?size=626&ext=jpg" width="60%">
                     <br><br>
                     <p> This vaccination camp is being organized to help ensure the safety and well-being of our community members, as we believe that getting vaccinated is one of the most effective ways to combat the pandemic. The vaccines that we will be administering have been authorized by the World Health Organization and are safe and effective to everyone. Its necessary for each individual to be vaccinated to be safe from the virus.</p>
                     </div>
                  </div>
              </div>
            </div>
         </div>
      </div>   
 </section>
    

 <footer class="footer">
    <div class="container">
        <div class="row">
            <div class="footer-col">
                <h3>OUR SERVICES</h3>
                <ul>
                    <h6> ->Store medical records at one place</h6>
                      <h6>  ->Track your health status on a daily basis</h6>
                    <h6>->Provides health charts for individual tests</h6>
                    <h6>->Gives information relating to hospital campaigns</h6>
                </ul>
                <img src="https://www.world3d.com/wp-content/uploads/2016/07/medical-GIF.gif" alt="" align="left" width="80%">
            </div>
            <div class="animate">
                <!--img src="https://www.world3d.com/wp-content/uploads/2016/07/medical-GIF.gif" alt="" align="left" width="40%"-->
            </div>
            
            
        </div>
    </div>

    
</footer>

  
 </body>
</html>

<script>
$(document).ready(function(){
 
 function load_unseen_notification(view = '')
 {
  $.ajax({
   url:"fetch.php",
   method:"POST",
   data:{view:view},
   dataType:"json",
   success:function(data)
   {
    $('.dropdown-menu').html(data.notification);
    if(data.unseen_notification > 0)
    {
     $('.count').html(data.unseen_notification);
    }
   }
  });
 }
 
 load_unseen_notification();
 
 $('#comment_form').on('submit', function(event){
  event.preventDefault();
  if($('#subject').val() != '' && $('#comment').val() != '')
  {
   var form_data = $(this).serialize();
   $.ajax({
    url:"insert.php",
    method:"POST",
    data:form_data,
    success:function(data)
    {
     $('#comment_form')[0].reset();
     load_unseen_notification();
    }
   });
  }
  else
  {
   alert("Both Fields are Required");
  }
 });
 
 $(document).on('click', '.dropdown-toggle', function(){
  $('.count').html('');
  load_unseen_notification('yes');
 });
 
 setInterval(function(){ 
  load_unseen_notification();; 
 }, 5000);
 
});
</script>
