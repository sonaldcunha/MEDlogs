<?php 
	$con=mysqli_connect("localhost","root","root","db_birthday_reminder");
?>