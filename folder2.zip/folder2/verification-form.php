<div class="error"></div>
<div class="success"></div>
<form id="frm-mobile-verification" onsubmit="verifyOTP(event);">
	<div class="form-row">
		<label>OTP is sent to Your Mobile Number</label>		
	</div>

	<div class="form-row">
		<input type="number"  id="mobileOtp" class="form-input" placeholder="Enter the OTP">		
	</div>

	<div class="row">
		<button id="verify" type="submit" class="btnVerify" >Verify</button>		
	</div>
	<br>
	<!-- <div class="row">
		<input id="verify" type="button" class="btnVerify" value="View record" onClick="viewRecord();">		
	</div> -->
	
</form>
