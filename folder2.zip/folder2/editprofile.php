<?php
// Start a session to track the user's information
session_start();

// Connect to the database
$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = 'root';
$dbname = 'myhmsdb';
$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);

// Check for errors in connecting to the database
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Get the user's ID from the session
$pid = $_SESSION['pid'];

// Retrieve the user's current information from the database
$sql = "SELECT * FROM patreg WHERE pid='$pid'";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);

// If the form has been submitted, update the user's information in the database
if (isset($_POST['submit'])) {
    $fname = mysqli_real_escape_string($conn, $_POST['fname']);
    $lname = mysqli_real_escape_string($conn, $_POST['lname']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    
    $contact = mysqli_real_escape_string($conn, $_POST['contact']);

    $sql = "UPDATE patreg SET fname='$fname', lname='$lname', email='$email',contact='$contact' WHERE pid='$pid'";
    mysqli_query($conn, $sql);

    // Update the user's session information
    $_SESSION['fname'] = $fname;
    $_SESSION['lname'] = $lname;
    $_SESSION['email'] = $email;
    
    $_SESSION['contact'] = $contact;

    // Redirect the user to their profile page
    header("Location: editprofile.php");
}

mysqli_close($conn);
?>
<html>
    <head>
        <style>
     *{
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: 'Poppins',sans-serif;
}
body{
  height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 10px;
  background: linear-gradient(135deg, lightgreen, #7e97af);
}
.container{
  max-width: 700px;
  width: 100%;
  background-color: #fff;
  padding: 25px 30px ;
  border-radius: 5px;
  box-shadow: 0 5px 10px rgba(0,0,0,0.15);
}
.container .title{
  font-size: 25px;
  font-weight: 500;
  position: relative;
}
.container .title::before{
  content: "";
  position: absolute;
  left: 0;
  bottom: 0;
  height: 3px;
  width: 30px;
  border-radius: 5px;
  background: linear-gradient(135deg, #008000, #3cbc3c);
}

.user-details .input-box input{
  height: 34px;
  width: 100%;
  outline: none;
  font-size: 14px;
  border-radius: 5px;
  padding-left: 15px;
  border: 1px solid #ccc;
  border-bottom-width: 2px;
  transition: all 0.3s ease;
}
.user-details .input-box input:focus,
.user-details .input-box input:valid{
  border-color: #5999b6;
}
form .button{
  height: 35px;
  margin: 20px 0
}
form .user-details .input-box{
  margin-bottom: 15px;
  padding-top:5px;
  width: 100%;
  }
  form .category{
    width: 100%;
  }
 form .button input{
  height: 95%;
  width: 100%;
   border-radius: 5px;
   border: none;
   color: #fff;
   font-size: 18px;
   font-weight: 500;
   letter-spacing: 1px;
   cursor: pointer;
   transition: all 0.3s ease;
   background: linear-gradient(135deg, #008000, #3cbc3c);
 }
 form .button input:hover{
  /* transform: scale(0.99); */
  background: linear-gradient(-135deg, #71b7e6, #b6c9d4);
  }
</style>
</head>
<!-- HTML form for editing user profile -->
<div class="container">
<div class="title">Update users</div>
<form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
<div class="user-details">
<div class="input-box">
    <label for="fname">First Name:</label>
    <input type="text" name="fname" value="<?php echo $row['fname']; ?>" required><br>
</div>
<div class="input-box">
    <label for="lname">Last Name:</label>
    <input type="text" name="lname" value="<?php echo $row['lname']; ?>" required><br>
    </div>
<div class="input-box">
    <label for="email">Email:</label>
    <input type="email" name="email" value="<?php echo $row['email']; ?>" required><br>
    </div>
<div class="input-box">
    

    <label for="contact">Contact:</label>
    <input type="text" name="contact" value="<?php echo $row['contact']; ?>" required><br>
</div>
<div class="button">
    <input type="submit" name="submit" value="Save Changes">
</div>
<div class="button">
<a href="admin-panel.php" style="color:green;">Back to MEDlogs features</a>
    </div>
</form>
</div>
</div>
</html>