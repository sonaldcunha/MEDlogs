<?php
session_start();
include('dbconfig1.php');
if($connection)
{
    // echo "Database Connected";
}
else
{
    header("Location: dbconfig1.php");
}

if(!$_SESSION['username'])
{
    header('Location: login.php');
}
?>
