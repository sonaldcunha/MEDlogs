<?php
include("db.php");
$hosp_id= $_GET['hosp_id'];
$query="delete from admintb where hosp_id='$hosp_id'";
$data=mysqli_query($con,$query);
if($data)
    {
      ?>
      <script>
      alert("deleted successfully");
      </script>
      <meta http-equiv = "refresh" content = "0; url = http://localhost/medical/medLOGS/adminhosp.php" />
      <?php
      }
      else
      {
        ?>
        <script>
        alert("Failed to delete");
        </script>
        <?php
        }
?>