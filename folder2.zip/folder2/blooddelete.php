<?php
include("dbcon.php");
$blood_id= $_GET['blood_id'];
$query="delete from blood where blood_id='$blood_id'";
$data=mysqli_query($con,$query);
if($data)
    {
      ?>
      <script>
      alert("deleted successfully");
      </script>
      <meta http-equiv = "refresh" content = "0; url = http://localhost/Medlogs%20admin/medLOGS/bloodview.php" />
      <?php
      }
      else
      {
        ?>
        <script>
        alert("Failed to delete");
        </script>
        <?php
        }
?>