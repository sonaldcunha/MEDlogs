<?php
$server= "localhost";
$user= "root";
$password= "root";
$db= "admin";
$con = mysqli_connect($server,$user,$password,$db);

if($con){
  ?>
  <script>
    // alert("connection successfull");
  </script>
  <?php
}
else{
  ?>
  <script>
    alert("NO connection ");
  </script>
  <?php
}


?>