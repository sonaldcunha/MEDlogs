<?php
include("func.php");
$pid= $_GET['pid'];
$query="delete from `patreg` where pid='$pid'";
$data=mysqli_query($con,$query);
if($data)
    {
      ?>
      <script>
      alert("deleted successfully");
      </script>
      <meta http-equiv = "refresh" content = "0; url = http://localhost/medical/medLOGS/adminuser.php" />
      <?php
      }
      else
      {
        ?>
        <script>
        alert("Failed to delete");
        </script>
        <?php
        }
?>